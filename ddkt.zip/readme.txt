Installing the Demonstration Test on your computer

The Demonstration Test can be installed on almost any
computer (PC, Macintosh, UNIX and others).  All of the
application files are bundled into one installation file.

To install the Demonstration Test:
 1) Save the file "ddkt.zip" in a directory (or folder)
on your computer (eg., c:\tmp on a Windows machine);
 2) Extract (unzip) the application files into any directory
or folder you choose (eg., c:\ddkt), using any standard
archiving/compression utility (eg., WinZip, PKZip, StuffIt).

To run the Demonstration Test:
 1) Start your web browser (you do not have to be connected
to the Internet);
 2) Point it to the Demonstration Test
directory on your computer;
 3) Open the file called "ddkt.htm"

NOTE:
You will need a recent-version web browser in order to run
the Demonstration Test.  The application has been tested on
Netscape 4.06 onwards, and Microsoft Internet Explorer 5 onwards.
These and other browsers are available for free download from
the manufacturers� web-sites. 

� Roads and Traffic Authority (NSW), 02 December 1999